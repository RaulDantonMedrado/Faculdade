'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const year = document.querySelector('#ano-atual');
  if (year) year.textContent = new Date().getFullYear();

  const menuButton = document.querySelector('.menu-toggle');
  const menu = document.querySelector('#menu-principal');
  if (menuButton && menu) {
    menuButton.addEventListener('click', () => {
      const isOpen = menu.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
    });
  }

  document.querySelectorAll('[data-counter]').forEach((counter) => {
    const target = Number(counter.dataset.counter);
    let value = 0;
    const step = Math.max(1, Math.ceil(target / 35));
    const timer = setInterval(() => {
      value = Math.min(target, value + step);
      counter.textContent = value.toLocaleString('pt-BR');
      if (value === target) clearInterval(timer);
    }, 28);
  });

  const mask = (selector, formatter) => {
    const input = document.querySelector(selector);
    if (!input) return;
    input.addEventListener('input', () => {
      input.value = formatter(input.value);
    });
  };

  mask('#cpf', (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    return digits
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  });

  mask('#telefone', (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length <= 10) {
      return digits
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{4})(\d)/, '$1-$2');
    }
    return digits
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d)/, '$1-$2');
  });

  mask('#cep', (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 8);
    return digits.replace(/(\d{5})(\d)/, '$1-$2');
  });

  document.querySelectorAll('[data-action="doar"]').forEach((button) => {
    button.addEventListener('click', () => {
      const feedback = document.querySelector('#donation-feedback');
      const project = button.dataset.projeto || 'o projeto';
      if (feedback) feedback.textContent = `A jornada de doação para “${project}” foi iniciada (simulação acadêmica).`;
      else alert(`Doação para “${project}” iniciada — simulação acadêmica.`);
    });
  });

  document.querySelectorAll('.donation-options button').forEach((button) => {
    button.addEventListener('click', () => {
      const feedback = document.querySelector('#donation-feedback');
      if (feedback) feedback.textContent = `Valor selecionado: R$ ${Number(button.dataset.value).toLocaleString('pt-BR')}. Esta etapa é uma simulação acadêmica.`;
    });
  });

  const form = document.querySelector('#cadastro-form');
  const feedback = document.querySelector('#form-feedback');
  if (form && feedback) {
    const params = new URLSearchParams(window.location.search);
    const interesse = params.get('interesse');
    if (interesse && document.querySelector('#interesse')) {
      document.querySelector('#interesse').value = interesse;
    }

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        feedback.textContent = 'Revise os campos destacados e tente novamente.';
        return;
      }
      feedback.textContent = 'Cadastro enviado com sucesso! Nesta versão acadêmica, o envio é apenas uma simulação.';
      form.reset();
    });
  }
});
