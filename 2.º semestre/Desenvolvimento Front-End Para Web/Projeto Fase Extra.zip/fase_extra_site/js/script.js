/* Fase Extra — interações compartilhadas entre as cinco páginas. */

// Tema escuro por padrão, com preferência salva para as próximas visitas.
const themeToggle = document.querySelector('.theme-toggle');
if (themeToggle) {
  const themeRoot = document.documentElement;
  let savedTheme = 'dark';
  try {
    savedTheme = localStorage.getItem('fase-extra-theme') || themeRoot.dataset.theme || 'dark';
  } catch (error) {
    // Se o navegador bloquear o armazenamento, o tema atual continua funcionando.
  }
  themeRoot.dataset.theme = savedTheme;

  function updateThemeButton() {
    const isDark = themeRoot.dataset.theme === 'dark';
    themeToggle.setAttribute('aria-pressed', String(isDark));
    themeToggle.setAttribute('aria-label', isDark ? 'Ativar modo claro' : 'Ativar modo escuro');
    themeToggle.innerHTML = `<span aria-hidden="true">${isDark ? '☼' : '☾'}</span>`;
  }

  themeToggle.addEventListener('click', () => {
    const nextTheme = themeRoot.dataset.theme === 'dark' ? 'light' : 'dark';
    themeRoot.dataset.theme = nextTheme;
    try { localStorage.setItem('fase-extra-theme', nextTheme); } catch (error) { /* armazenamento opcional */ }
    updateThemeButton();
  });
  updateThemeButton();
}

// Se a imagem principal de Zelda falhar, tenta uma segunda captura de Ocarina of Time.
// Se as duas fontes externas estiverem indisponíveis, usa uma arte SVG local de contingência.
document.querySelectorAll('img[data-fallback]').forEach((image) => {
  image.addEventListener('error', () => {
    const attempt = Number(image.dataset.fallbackAttempt || 0);
    if (attempt === 0) {
      image.dataset.fallbackAttempt = '1';
      image.src = image.dataset.fallback;
    } else if (attempt === 1) {
      image.dataset.fallbackAttempt = '2';
      image.src = 'imagens/ocarina-fallback.svg';
    } else {
      image.removeAttribute('data-fallback');
    }
  });
});


// Menu responsivo: o elemento só existe nas páginas que carregam o cabeçalho.
const menuButton = document.querySelector('.menu-toggle');
const mainMenu = document.querySelector('.main-nav');

if (menuButton && mainMenu) {
  menuButton.addEventListener('click', () => {
    const isExpanded = menuButton.getAttribute('aria-expanded') === 'true';
    menuButton.setAttribute('aria-expanded', String(!isExpanded));
    menuButton.setAttribute('aria-label', isExpanded ? 'Abrir menu de navegação' : 'Fechar menu de navegação');
    mainMenu.classList.toggle('is-open', !isExpanded);
  });

  // Fecha o menu após a escolha de uma página em telas pequenas.
  mainMenu.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Abrir menu de navegação');
      mainMenu.classList.remove('is-open');
    });
  });

  // Se a janela voltar ao formato desktop, remove o estado aberto do menu móvel.
  window.addEventListener('resize', () => {
    if (window.innerWidth > 680) {
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Abrir menu de navegação');
      mainMenu.classList.remove('is-open');
    }
  });
}

// Filtro da página Explore: combina palavra-chave e categoria selecionada.
const gameSearch = document.querySelector('#game-search');
const categoryFilter = document.querySelector('#category-filter');
const gameGrid = document.querySelector('#game-grid');
const resultsCount = document.querySelector('#results-count');
const emptyState = document.querySelector('#empty-state');
const clearFiltersButton = document.querySelector('#clear-filters');
const emptyClearButton = document.querySelector('#empty-clear');

if (gameSearch && categoryFilter && gameGrid && resultsCount && emptyState) {
  const gameCards = Array.from(gameGrid.querySelectorAll('.game-card'));

  function filterGames() {
    const searchTerm = gameSearch.value.trim().toLocaleLowerCase('pt-BR');
    const selectedCategory = categoryFilter.value;
    let visibleCount = 0;

    gameCards.forEach((card) => {
      const searchableText = `${card.dataset.search} ${card.textContent}`.toLocaleLowerCase('pt-BR');
      const matchesWord = searchTerm === '' || searchableText.includes(searchTerm);
      const matchesCategory = selectedCategory === 'all' || card.dataset.category === selectedCategory;
      const shouldShow = matchesWord && matchesCategory;

      card.hidden = !shouldShow;
      if (shouldShow) visibleCount += 1;
    });

    resultsCount.textContent = visibleCount === 1
      ? 'Exibindo 1 jogo.'
      : `Exibindo ${visibleCount} jogos.`;
    emptyState.hidden = visibleCount !== 0;
    gameGrid.hidden = visibleCount === 0;
  }

  function clearFilters() {
    gameSearch.value = '';
    categoryFilter.value = 'all';
    filterGames();
    gameSearch.focus();
  }

  gameSearch.addEventListener('input', filterGames);
  categoryFilter.addEventListener('change', filterGames);
  if (clearFiltersButton) clearFiltersButton.addEventListener('click', clearFilters);
  if (emptyClearButton) emptyClearButton.addEventListener('click', clearFilters);
  filterGames();
}

// Validação do formulário: demonstra a conferência, sem enviar ou armazenar dados.
const contactForm = document.querySelector('#contact-form');

if (contactForm) {
  const fields = {
    name: contactForm.querySelector('#name'),
    email: contactForm.querySelector('#email'),
    subject: contactForm.querySelector('#subject'),
    message: contactForm.querySelector('#message')
  };
  const feedback = contactForm.querySelector('#form-feedback');
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function showFieldError(field, message) {
    const errorElement = contactForm.querySelector(`#${field.id}-error`);
    field.setAttribute('aria-invalid', message ? 'true' : 'false');
    if (errorElement) errorElement.textContent = message;
  }

  function validateField(field) {
    const value = field.value.trim();
    let errorMessage = '';

    if (value === '') {
      errorMessage = 'Preencha este campo. Não use apenas espaços em branco.';
    } else if (field.type === 'email' && !emailPattern.test(value)) {
      errorMessage = 'Digite um endereço de e-mail válido.';
    }

    showFieldError(field, errorMessage);
    return errorMessage === '';
  }

  Object.values(fields).forEach((field) => {
    if (!field) return;
    field.addEventListener('input', () => {
      // Revalida o campo após a primeira tentativa de envio ou se já estiver marcado.
      if (field.getAttribute('aria-invalid') === 'true') validateField(field);
      if (feedback) {
        feedback.textContent = '';
        feedback.className = 'form-feedback';
      }
    });
  });

  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const validationResults = Object.values(fields).map((field) => validateField(field));
    const isFormValid = validationResults.every(Boolean);

    if (!isFormValid) {
      feedback.textContent = 'Revise os campos indicados antes de continuar.';
      feedback.className = 'form-feedback error';
      const firstInvalid = Object.values(fields).find((field) => field.getAttribute('aria-invalid') === 'true');
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    feedback.textContent = 'Dados validados com sucesso. Esta demonstração não enviou nem armazenou sua mensagem.';
    feedback.className = 'form-feedback success';
    contactForm.reset();
    Object.values(fields).forEach((field) => showFieldError(field, ''));
  });
}

// Perguntas frequentes: botões nativos garantem operação com mouse e teclado.
const faqButtons = document.querySelectorAll('.faq-question');

faqButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const isExpanded = button.getAttribute('aria-expanded') === 'true';
    const answerId = button.getAttribute('aria-controls');
    const answer = document.getElementById(answerId);

    button.setAttribute('aria-expanded', String(!isExpanded));
    if (answer) answer.hidden = isExpanded;
  });
});
