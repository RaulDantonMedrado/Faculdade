
function calcular() {

    var valor1 = parseFloat(document.getElementById("valor1").value);
    var valor2 = parseFloat(document.getElementById("valor2").value);

    var opcao = document.querySelector(
        'input[name="operacao"]:checked'
    );

    if (isNaN(valor1) || isNaN(valor2) || !opcao) {
        alert("Preencha os valores e selecione uma operação!");
        return;
    }

    var resultado;

    switch (opcao.value) {

        case "soma":
            resultado = valor1 + valor2;
            break;

        case "subtracao":
            resultado = valor1 - valor2;
            break;

        case "multiplicacao":
            resultado = valor1 * valor2;
            break;

        case "divisao":
            if (valor2 === 0) {
                alert("Não é possível dividir por zero!");
                return;
            }

            resultado = valor1 / valor2;
            break;
    }

    document.getElementById("resultado").value = resultado;
}

document.getElementById("calcular").addEventListener("click", calcular);
